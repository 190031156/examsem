export class Product 
{
    Product_Name: string;
    Brand : string;
    id: string;
    Description: string;
    price: number;
    Images: string;
}