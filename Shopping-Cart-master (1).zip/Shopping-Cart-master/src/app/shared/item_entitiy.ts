import { Product } from './productentitiy';

export class Item
{
    product: Product;
    quantity: number;
};