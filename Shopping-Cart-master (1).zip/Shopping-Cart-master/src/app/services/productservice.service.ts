import { Injectable } from '@angular/core';
import { Product} from '../shared/productentitiy';
@Injectable({
  providedIn: 'root'
})
export class ProductserviceService {

  private products: Product[];
  constructor() {

    this.products = [

      {
        
        Product_Name: "Women's adidas Running PulseBoost HD Shoes",
        id: "G6934",
        price: 12999,
        Brand: "SPORT PERFORMANCE",
        Description: "Designed for urban running, these shoes are made of breathable knit with a foot-hugging fit. Strategically placed non-stretch zones, and cushioning delivers a responsive ride.",
        Images:
          "https://content.adidas.co.in/static/Product-G26934/Women_RUNNING_SHOES_LOW_G26934_1.jpg",
      },
      {
        Product_Name: "Unisex adidas Originals Skateboarding Shoes",
        id: "EE6122",
        price: 5999,
        Brand: "ORIGINALS",
        Description: "These lightweight canvas skate shoes feature design details inspired by the wide-angle fisheye lens that gave skateboarding its unique visual style.Strategically placed non-stretch zones.",
        Images:
          "https://content.adidas.co.in/static/Product-EE6122/Unisex_SKATEBOARDING_VULCANIZED_SHOES_LOW_EE6122_1.jpg",
      },
      {
        Product_Name: "Men's Running Staredge Shoes",
        id: "CM4659",
        price: 8999,
        Brand: "CORE / NEO",
        Description: "These men's running shoes keep you comfortable so you stay focused on your running goals. They feature a textile upper that wraps around the midfoot to give you stability where you need it most.Strategically placed non-stretch zones.",
        Images: 
          "https://content.adidas.co.in/static/Product-CM4659/MEN_CORE_RUNNING_SHOES_CM4659_1.jpg",
          
      },
      {
        Product_Name: "Women's adidas Running Edge Lux 3 Shoes",
        id: "F36671",
        price: 7999,
        Brand: "SPORT PERFORMANCE",
        Description: " The upper is made of lightweight stretch mesh for a barely there feel. Designed for indoor and outdoor running, the shoes feature springy cushioning to keep you comfortable over the miles.",
        Images: 
          "https://content.adidas.co.in/static/Product-F36671/Women_RUNNING_SHOES_LOW_F36671_1.jpg",
         
      },
      {
        Product_Name: "Men's adidas Running Spartum Shoes",
        id: "CM4900",
        price: 4299,
        Brand: "CORE / NEO",
        Description: "Great everyday trainer for modern runner to go that extra mile. They have a knit-mesh upper, EVA midsole and Rubber outsole provide comfort and support to their every step.",
        Images:
          "https://content.adidas.co.in/static/Product-CM4900/adidas_CM4900_1.jpg",
          
      },
      {
        Product_Name: "Men's adidas Running Spartum Shoes",
        id: "CM4899",
        price: 4299,
        Brand: "CORE / NEO",
        Description: "Great everyday trainer for modern runner to go that extra mile. They have a knit-mesh upper, EVA midsole and Rubber outsole provide comfort and support to their every step.",
        Images:
          "https://content.adidas.co.in/static/Product-CM4899/MEN_CORE-RUNNING_SHOES_CM4899_1.jpg",
          
      },
      {
        Product_Name: "Men's Running Spartum Shoes",
        id: "CM4901",
        price: 4299,
        Brand: "CORE / NEO",
        Description: "Great everyday trainer for modern runner to go that extra mile. They have a knit-mesh upper, EVA midsole and Rubber outsole provide comfort and support to their every step.",
        Images: 
          "https://content.adidas.co.in/static/Product-CM4901/MEN_CORE-RUNNING_SHOES_CM4901_1.jpg",
          
      },
      {
        Product_Name: "Men's adidas Running Jerzo Shoes",
        id: "CM4830",
        price: 5299,
        Brand: "CORE / NEO",
        Description: "They feature breathable mesh upper with a supportive cage that wraps around the midfoot to give you stability where you need it most and durable Rubber outsole for long-lasting wear.",
        Images: 
          "https://content.adidas.co.in/static/Product-CM4830/MEN_CORE-RUNNING_SHOES_CM4830_1.jpg",
      },
      {
        Product_Name: "WOMEN'S ADIDAS SPORT INSPIRED COURTSET SHOES",
        id: "AW4209",
        price: 4999,
        Brand: "CORE / NEO",
        Description: "These women's tennis-inspired shoes feature a classic design with a soft suede upper and a rubber cupsole with a vulcanised look.",
        Images:
          "https://content.adidas.co.in/static/Product-AW4209/Women_CORE_SHOES_LOW_AW4209_1.jpg",
          
      },
      {
        Product_Name: "Women's adidas by Stella Mccartney Running PulseBoost HD Shoes",
        id: "G25877",
        price: 12999,
        Brand: "SPORT PERFORMANCE",
        Description: "Sprint toward the finish line of your 10K in these adidas by Stella McCartney running shoes. The lightweight, perforated rubber outsole helps propel you forward with rapid acceleration. Every step is charged with energy-returning cushioning.",
        Images:
          "https://content.adidas.co.in/static/Product-G25877/Women_RUNNING_SHOES_LOW_G25877_1.jpg",
         
      },
      {
        Product_Name: "Men's adidas Running Equil Shoes",
        id: "CM4855",
        price: 4999,
        Brand: "CORE / NEO",
        Description: "A well cushioned shoe with a fresher look that will appeal to young runners. Features Textile-Mesh upper for maximum ventilation, Cloudfoam midsole cushions each step so you stay comfortable and motivated every day and durable Rubber outsole for long-lasting wear.",
        Images: 
          "https://content.adidas.co.in/static/Product-CM4855/MEN_CORE-RUNNING_SHOES_CM4855_1.jpg",
          
      },
      {
        Product_Name: "Women's adidas Tennis Courtsmash Shoes",
        id: "EE8452",
        price: 4999,
        Brand: "CORE / NEO",
        Description: "Take to the court with confidence in these women's tennis shoes. Designed for the casual player, they feature a durable and stable leather upper with mesh at the heel. Lightweight cushioning keeps you comfortable during long rallies, while a rubber outsole delivers strong grip.",
        Images: 
          "https://content.adidas.co.in/static/Product-EE8452/Women_TENNIS_SHOES_LOW_EE8452_1.jpg",
          
      },
      {
        Product_Name: "Men's Running Hellion Z Shoes",
        id: "CM4813",
        price: 3299,
        Brand: "CORE / NEO",
        Description: "The Hellion Z Running shoes for men with new design pattern for any runner looking for trendy yet extremely comfortable running shoe. An excellent combination of breathable Mesh with synthetic overlays on the upper makes it very comfortable for your feet on the run. Durable, non slippery, blown out one piece super grip EVA midsole and Rubber outsole ensures maximum stability and grip on the ground.",
        Images: 
          "https://content.adidas.co.in/static/Product-CM4813/MEN_CORE-RUNNING_SHOES_CM4813_1.jpg",
         
      },
      {
        Product_Name: "Women's adidas Running Duramo 9 Shoes",
        id: "EE8351",
        price: 5999,
        Brand: "CORE / NEO",
        Description: "These women's neutral running shoes will get you on the road to your goals. A sandwich mesh upper offers lightweight breathability, while a seamless print overlay adds support for a stable stride. The midsole offers pillow-soft Cloudfoam cushioning that eases every stride.",
        Images:
          "https://content.adidas.co.in/static/Product-EE8351/Women_CORE_RUNNING_SHOES_LOW_EE8351_1.jpg",
          
      },
      {
        Product_Name: "Women's adidas by Stella Mccartney Running PulseBoost HD Shoes",
        id: "G28329",
        price: 12999,
        Brand: "SPORT PERFORMANCE",
        Description: "Sprint toward the finish line of your 10K in these adidas by Stella McCartney running shoes. The lightweight, perforated rubber outsole helps propel you forward with rapid acceleration. Every step is charged with energy-returning cushioning.",
        Images:
          "https://content.adidas.co.in/static/Product-G28329/Women_RUNNING_SHOES_LOW_G28329_1.jpg",
          
      },
      {
        Product_Name: "Men's Running Thrum Shoes",
        id: "CM4857",
        price: 5999,
        Brand: "CORE / NEO",
        Description: "These men's running shoes keep you comfortable so you stay focused on your goals. They feature a textile, mesh and synthetic upper along with Cloudfoam midsole provides optimum cushioning  where you need it most and durable Rubber outsole for long-lasting wear.",
        Images: 
          "https://content.adidas.co.in/static/Product-CM4857/MEN_CORE-RUNNING_SHOES_CM4857_1.jpg",
          
      },
    
    ]
  }

  getAll(): Product[] {
    return this.products;
}

 getSelectedIndex(id: string) {
  for (var i = 0; i < this.products.length; i++) {
      if (this.products[i].id === id) {
          return i;
      }
  }
  return -1;
}

getP(id: string): Product {
  return this.products[this.getSelectedIndex(id)];
}



}
