import { Component, OnInit } from '@angular/core';
import { ProductserviceService } from '../services/productservice.service';
import {Product} from '../shared/productentitiy';
@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.scss']
})
export class ProductComponent implements OnInit {
 products: Product[];
  constructor( private productService: ProductserviceService) { }

  ngOnInit(): void {
    this.products = this.productService.getAll();
  }

}
